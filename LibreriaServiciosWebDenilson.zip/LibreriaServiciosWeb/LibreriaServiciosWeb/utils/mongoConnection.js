const mongoose= require('mongoose');

mongoose.connect(
    'mongodb+srv://denilsondh:Garbancito1@cluster0.ibdbj5e.mongodb.net/?retryWrites=true&w=majority'
    
)
.then(()=>console.log('Conexion exitosa a MongoseDB'))
.catch(err=>console.error('Error al conectar MongoDB:',err));

module.exports = mongoose;